define(
"dojo/cldr/nls/zh/buddhist", //begin v1.x content
{
	"dateFormatItem-yM": "Gy年M月",
	"dateFormatItem-yyyyMMMEd": "Gy年M月d日E",
	"dateFormatItem-yQ": "Gy年第Q季度",
	"dayPeriods-format-wide-pm": "下午",
	"eraNames": [
		"佛历"
	],
	"dateFormatItem-MMMEd": "M月d日E",
	"dateFormatItem-hms": "ah:mm:ss",
	"dateFormatItem-yQQQ": "Gy年第Q季度",
	"days-standAlone-wide": [
		"星期日",
		"星期一",
		"星期二",
		"星期三",
		"星期四",
		"星期五",
		"星期六"
	],
	"dateFormatItem-MMM": "LLL",
	"dateFormatItem-Gy": "Gy年",
	"dayPeriods-format-wide-am": "上午",
	"quarters-standAlone-abbr": [
		"1季度",
		"2季度",
		"3季度",
		"4季度"
	],
	"dateFormatItem-y": "Gy年",
	"timeFormat-full": "zzzzah:mm:ss",
	"dateFormatItem-yyyy": "Gy年",
	"months-standAlone-abbr": [
		"1月",
		"2月",
		"3月",
		"4月",
		"5月",
		"6月",
		"7月",
		"8月",
		"9月",
		"10月",
		"11月",
		"12月"
	],
	"dateFormatItem-Ed": "d日E",
	"dateFormatItem-yMMM": "Gy年M月",
	"days-standAlone-narrow": [
		"日",
		"一",
		"二",
		"三",
		"四",
		"五",
		"六"
	],
	"eraAbbr": [
		"佛历"
	],
	"dateFormat-long": "Gy年M月d日",
	"timeFormat-medium": "ah:mm:ss",
	"dateFormatItem-Hm": "HH:mm",
	"dateFormat-medium": "Gyyyy-M-d",
	"dateFormatItem-Hms": "HH:mm:ss",
	"dayPeriods-format-narrow-pm": "下午",
	"dateFormatItem-yMd": "y/M/d",
	"quarters-standAlone-wide": [
		"第一季度",
		"第二季度",
		"第三季度",
		"第四季度"
	],
	"dateFormatItem-ms": "mm:ss",
	"dayPeriods-format-narrow-am": "上午",
	"months-standAlone-wide": [
		"一月",
		"二月",
		"三月",
		"四月",
		"五月",
		"六月",
		"七月",
		"八月",
		"九月",
		"十月",
		"十一月",
		"十二月"
	],
	"dateFormatItem-yyyyMd": "Gy-M-d",
	"dateFormatItem-yyyyMMMd": "Gy年M月d日",
	"dateFormatItem-yyyyMEd": "Gy-M-dE",
	"dateFormatItem-MMMd": "M月d日",
	"timeFormat-long": "zah:mm:ss",
	"months-format-abbr": [
		"1月",
		"2月",
		"3月",
		"4月",
		"5月",
		"6月",
		"7月",
		"8月",
		"9月",
		"10月",
		"11月",
		"12月"
	],
	"dateFormatItem-H": "H时",
	"timeFormat-short": "ah:mm",
	"quarters-format-abbr": [
		"1季度",
		"2季度",
		"3季度",
		"4季度"
	],
	"days-format-abbr": [
		"周日",
		"周一",
		"周二",
		"周三",
		"周四",
		"周五",
		"周六"
	],
	"dateFormatItem-M": "M月",
	"days-format-narrow": [
		"日",
		"一",
		"二",
		"三",
		"四",
		"五",
		"六"
	],
	"dateFormatItem-yMMMd": "y年M月d日",
	"dateFormatItem-MEd": "M-dE",
	"dateFormatItem-yyyyQQQ": "Gy年QQQQ",
	"days-standAlone-short": [
		"周日",
		"周一",
		"周二",
		"周三",
		"周四",
		"周五",
		"周六"
	],
	"dateFormatItem-hm": "ah:mm",
	"days-standAlone-abbr": [
		"周日",
		"周一",
		"周二",
		"周三",
		"周四",
		"周五",
		"周六"
	],
	"dateFormat-short": "Gy-M-d",
	"dateFormatItem-yyyyM": "Gy-M",
	"dateFormatItem-yMMMEd": "Gy年M月d日E",
	"dateFormat-full": "Gy年M月d日EEEE",
	"dateFormatItem-Md": "M-d",
	"dateFormatItem-yMEd": "Gy年M月d日，E",
	"dateFormatItem-yyyyQ": "Gy年QQQ",
	"months-format-wide": [
		"一月",
		"二月",
		"三月",
		"四月",
		"五月",
		"六月",
		"七月",
		"八月",
		"九月",
		"十月",
		"十一月",
		"十二月"
	],
	"days-format-short": [
		"周日",
		"周一",
		"周二",
		"周三",
		"周四",
		"周五",
		"周六"
	],
	"dateFormatItem-yyyyMMM": "Gy年M月",
	"dateFormatItem-d": "d日",
	"quarters-format-wide": [
		"第一季度",
		"第二季度",
		"第三季度",
		"第四季度"
	],
	"eraNarrow": [
		"佛历"
	],
	"days-format-wide": [
		"星期日",
		"星期一",
		"星期二",
		"星期三",
		"星期四",
		"星期五",
		"星期六"
	],
	"dateFormatItem-h": "ah时"
}
//end v1.x content
);